from __future__ import annotations
import base64, json
from datetime import datetime, timezone

from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature

def canonical_json(obj) -> str:
    # Stable ordering is critical for signature verification
    return json.dumps(obj, separators=(",", ":"), sort_keys=True)

def sign_payload_ed25519(private_key: ed25519.Ed25519PrivateKey, payload_obj) -> str:
    data = canonical_json(payload_obj).encode()
    sig = private_key.sign(data)
    return base64.b64encode(sig).decode()

def verify_payload_ed25519(cert_pem: str, payload_obj, sig_b64: str) -> tuple[bool, str]:
    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode())
        pub = cert.public_key()
        if not isinstance(pub, ed25519.Ed25519PublicKey):
            return False, "Unsupported public key type"
        # validity window check
        now = datetime.now(timezone.utc)
        if cert.not_valid_before_utc > now or cert.not_valid_after_utc < now:
            return False, "Certificate expired/not yet valid"

        data = canonical_json(payload_obj).encode()
        sig = base64.b64decode(sig_b64.encode())
        pub.verify(sig, data)
        return True, "Signature valid"
    except InvalidSignature:
        return False, "Invalid signature"
    except Exception as e:
        return False, f"Verification error: {e}"