from __future__ import annotations
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from app.core.config import settings

def _ensure_dirs():
    Path(settings.ca_dir).mkdir(parents=True, exist_ok=True)
    Path(settings.key_dir).mkdir(parents=True, exist_ok=True)

def ca_paths():
    return {
        "ca_key": os.path.join(settings.ca_dir, "ca_ed25519_key.pem"),
        "ca_cert": os.path.join(settings.ca_dir, "ca_cert.pem"),
        "sign_key": os.path.join(settings.key_dir, "invoice_sign_ed25519_key.pem"),
        "sign_cert": os.path.join(settings.key_dir, "invoice_sign_cert.pem"),
    }

def ensure_ca_and_signer() -> dict:
    """
    Creates a local CA cert and an invoice signing key+cert if missing.
    Returns PEM strings for CA cert and signer cert.
    """
    _ensure_dirs()
    p = ca_paths()

    # --- CA key ---
    if not os.path.exists(p["ca_key"]):
        ca_key = ed25519.Ed25519PrivateKey.generate()
        with open(p["ca_key"], "wb") as f:
            f.write(ca_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            ))
    else:
        with open(p["ca_key"], "rb") as f:
            ca_key = serialization.load_pem_private_key(f.read(), password=None)

    # --- CA cert ---
    if not os.path.exists(p["ca_cert"]):
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "SecureElectroStore Local CA"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SecureElectroStore"),
        ])
        now = datetime.now(timezone.utc)
        ca_cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(ca_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(days=1))
            .not_valid_after(now + timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .sign(private_key=ca_key, algorithm=None)
        )
        with open(p["ca_cert"], "wb") as f:
            f.write(ca_cert.public_bytes(serialization.Encoding.PEM))
    else:
        with open(p["ca_cert"], "rb") as f:
            ca_cert = x509.load_pem_x509_certificate(f.read())

    # --- Signer key ---
    if not os.path.exists(p["sign_key"]):
        sign_key = ed25519.Ed25519PrivateKey.generate()
        with open(p["sign_key"], "wb") as f:
            f.write(sign_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            ))
    else:
        with open(p["sign_key"], "rb") as f:
            sign_key = serialization.load_pem_private_key(f.read(), password=None)

    # --- Signer cert ---
    if not os.path.exists(p["sign_cert"]):
        now = datetime.now(timezone.utc)
        subject = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "Invoice Signing Key"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SecureElectroStore"),
        ])
        signer_cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(ca_cert.subject)
            .public_key(sign_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(days=1))
            .not_valid_after(now + timedelta(days=365))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(
                x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CODE_SIGNING]),
                critical=False
            )
            .sign(private_key=ca_key, algorithm=None)
        )
        with open(p["sign_cert"], "wb") as f:
            f.write(signer_cert.public_bytes(serialization.Encoding.PEM))
    else:
        with open(p["sign_cert"], "rb") as f:
            signer_cert = x509.load_pem_x509_certificate(f.read())

    return {
        "ca_cert_pem": ca_cert.public_bytes(serialization.Encoding.PEM).decode(),
        "sign_cert_pem": signer_cert.public_bytes(serialization.Encoding.PEM).decode(),
    }

def load_signing_private_key():
    p = ca_paths()
    with open(p["sign_key"], "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)

def load_signing_cert():
    p = ca_paths()
    with open(p["sign_cert"], "rb") as f:
        return x509.load_pem_x509_certificate(f.read())