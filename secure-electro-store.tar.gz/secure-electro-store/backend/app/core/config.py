from pydantic import BaseModel
import os

class Settings(BaseModel):
    app_env: str = os.getenv("APP_ENV", "dev")
    app_secret: str = os.getenv("APP_SECRET", "change_me")

    database_url: str = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg://app:app_pass@db:5432/app_db"
    )

    key_dir: str = os.getenv("KEY_DIR", "/data/keys")
    ca_dir: str = os.getenv("CA_DIR", "/data/ca")

    cors_origins: str = os.getenv("CORS_ORIGINS", "https://localhost")

settings = Settings()