import base64, hmac, hashlib, json, time
from typing import Optional, Dict, Any

from app.core.config import settings

def pbkdf2_hash_password(password: str, salt: bytes | None = None) -> str:
    if salt is None:
        salt = hashlib.sha256(str(time.time()).encode()).digest()[:16]
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000, dklen=32)
    return base64.b64encode(salt + dk).decode()

def pbkdf2_verify_password(password: str, stored_b64: str) -> bool:
    raw = base64.b64decode(stored_b64.encode())
    salt, dk = raw[:16], raw[16:]
    dk2 = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000, dklen=32)
    return hmac.compare_digest(dk, dk2)

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode())

def jwt_encode(payload: Dict[str, Any], exp_seconds: int = 3600) -> str:
    header = {"alg":"HS256","typ":"JWT"}
    payload = dict(payload)
    payload["exp"] = int(time.time()) + exp_seconds

    h = _b64url(json.dumps(header, separators=(",",":")).encode())
    p = _b64url(json.dumps(payload, separators=(",",":")).encode())
    msg = f"{h}.{p}".encode()
    sig = hmac.new(settings.app_secret.encode(), msg, hashlib.sha256).digest()
    return f"{h}.{p}.{_b64url(sig)}"

def jwt_decode(token: str) -> Optional[Dict[str, Any]]:
    try:
        h, p, s = token.split(".")
        msg = f"{h}.{p}".encode()
        sig = _b64url_decode(s)
        expected = hmac.new(settings.app_secret.encode(), msg, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(_b64url_decode(p))
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None