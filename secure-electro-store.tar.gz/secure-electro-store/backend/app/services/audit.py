import hashlib, json
from sqlalchemy.orm import Session
from app.models import AuditLog

def _canonical(obj) -> str:
    return json.dumps(obj, separators=(",", ":"), sort_keys=True)

def append_audit(db: Session, actor_user_id: int, action: str, entity: str, entity_id: str, data: dict):
    last = db.query(AuditLog).order_by(AuditLog.id.desc()).first()
    prev_hash = last.entry_hash if last else "0"*64

    payload = {
        "actor_user_id": actor_user_id,
        "action": action,
        "entity": entity,
        "entity_id": entity_id,
        "data": data,
        "prev_hash": prev_hash,
    }
    entry_hash = hashlib.sha256(_canonical(payload).encode()).hexdigest()

    row = AuditLog(
        actor_user_id=actor_user_id,
        action=action,
        entity=entity,
        entity_id=str(entity_id),
        data_json=_canonical(data),
        prev_hash=prev_hash,
        entry_hash=entry_hash,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row

def verify_chain(db: Session) -> tuple[bool, str]:
    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    prev = "0"*64
    for l in logs:
        payload = {
            "actor_user_id": l.actor_user_id,
            "action": l.action,
            "entity": l.entity,
            "entity_id": l.entity_id,
            "data": json.loads(l.data_json or "{}"),
            "prev_hash": prev,
        }
        expected = hashlib.sha256(_canonical(payload).encode()).hexdigest()
        if l.prev_hash != prev:
            return False, f"Broken prev_hash at audit_id={l.id}"
        if l.entry_hash != expected:
            return False, f"Tamper detected at audit_id={l.id}"
        prev = l.entry_hash
    return True, "Audit chain valid"