from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import Optional
import json
from app.core.crypto.pki import load_signing_cert
from cryptography.hazmat.primitives import serialization
from app.core.config import settings
from app.core.db import Base, engine, get_db
from app.core.security import pbkdf2_hash_password, pbkdf2_verify_password, jwt_encode
from app.core.crypto.pki import ensure_ca_and_signer, load_signing_private_key
from app.core.crypto.sign_verify import sign_payload_ed25519, verify_payload_ed25519, canonical_json
from app.models import User, Product, Order, RevokedCert
from app.deps import get_current_user, require_admin
from app.services.audit import append_audit, verify_chain

app = FastAPI(title="SecureElectroStore API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def _startup():
    Base.metadata.create_all(bind=engine)
    ensure_ca_and_signer()
    # bootstrap admin if none exists
    from sqlalchemy import select
    db = next(get_db())
    try:
        admin = db.query(User).filter(User.role == "admin").first()
        if not admin:
            admin = User(
                email="admin@local",
                password_hash=pbkdf2_hash_password("Admin123!"),
                role="admin",
                is_active=True,
            )
            db.add(admin)
            db.commit()
    finally:
        db.close()

@app.get("/api/health")
def health():
    return {"status": "ok"}

# ---------- Auth ----------
@app.post("/api/auth/register")
def register(payload: dict, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    if not email or not password:
        raise HTTPException(400, "email/password required")
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(409, "email already exists")
    u = User(email=email, password_hash=pbkdf2_hash_password(password), role="customer")
    db.add(u); db.commit(); db.refresh(u)
    return {"id": u.id, "email": u.email}

@app.post("/api/auth/login")
def login(payload: dict, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    u = db.query(User).filter(User.email == email).first()
    if not u or not pbkdf2_verify_password(password, u.password_hash):
        raise HTTPException(401, "invalid credentials")
    token = jwt_encode({"sub": u.id, "role": u.role}, exp_seconds=3600*6)
    return {"access_token": token, "role": u.role}

# ---------- Products ----------
@app.get("/api/products")
def list_products(db: Session = Depends(get_db)):
    rows = db.query(Product).order_by(Product.id.desc()).all()
    return [{"id": p.id, "name": p.name, "description": p.description, "price": p.price, "stock": p.stock} for p in rows]

@app.post("/api/admin/products")
def create_product(
    payload: dict,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    require_admin(user)

    p = Product(
        name=payload.get("name","").strip(),
        description=payload.get("description",""),
        price=str(payload.get("price","0.00")),
        stock=int(payload.get("stock",0)),
    )
    if not p.name:
        raise HTTPException(400, "name required")
    db.add(p); db.commit(); db.refresh(p)
    append_audit(db, user.id, "create_product", "product", str(p.id), {"name": p.name, "price": p.price, "stock": p.stock})
    return {"id": p.id}

# ---------- Orders + Signed Invoice ----------
@app.post("/api/orders/checkout")
def checkout(
    payload: dict,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)

    # payload: {items:[{product_id, qty}], address:"...", payment_ref:"mock"}
    items = payload.get("items") or []
    if not items:
        raise HTTPException(400, "items required")

    # compute total (simple string math via float for starter)
    total = 0.0
    norm_items = []
    for it in items:
        pid = int(it.get("product_id"))
        qty = int(it.get("qty", 1))
        prod = db.get(Product, pid)
        if not prod:
            raise HTTPException(404, f"product {pid} not found")
        if prod.stock < qty:
            raise HTTPException(400, f"insufficient stock for {prod.name}")
        price = float(prod.price)
        total += price * qty
        norm_items.append({"product_id": pid, "name": prod.name, "unit_price": prod.price, "qty": qty})

    # reduce stock
    for it in norm_items:
        prod = db.get(Product, it["product_id"])
        prod.stock -= it["qty"]
    db.commit()

    order = Order(user_id=user.id, status="placed", total=f"{total:.2f}")
    db.add(order); db.commit(); db.refresh(order)

    pki = ensure_ca_and_signer()
    signer_key = load_signing_private_key()
    signer_cert_pem = pki["sign_cert_pem"]

    invoice = {
        "order_id": order.id,
        "user_id": user.id,
        "items": norm_items,
        "total": order.total,
        "issued_at": order.created_at.isoformat() + "Z",
        "type": "invoice+warranty",
    }
    sig_b64 = sign_payload_ed25519(signer_key, invoice)

    order.invoice_json = canonical_json(invoice)
    order.invoice_sig_b64 = sig_b64
    order.signing_cert_pem = signer_cert_pem
    db.commit()

    append_audit(db, user.id, "checkout", "order", str(order.id), {"total": order.total, "items": norm_items})

    return {"order_id": order.id, "total": order.total}

@app.get("/api/orders/my")
def my_orders(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    rows = db.query(Order).filter(Order.user_id == user.id).order_by(Order.id.desc()).all()
    return [{
        "id": o.id,
        "status": o.status,
        "total": o.total,
        "created_at": o.created_at.isoformat() + "Z",
    } for o in rows]

@app.get("/api/orders/{order_id}/invoice")
def get_invoice(
    order_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    o = db.get(Order, order_id)
    if not o or o.user_id != user.id:
        raise HTTPException(404, "order not found")
    return {
        "invoice": json.loads(o.invoice_json),
        "signature_b64": o.invoice_sig_b64,
        "signing_cert_pem": o.signing_cert_pem,
    }

@app.post("/api/crypto/verify-invoice")
def verify_invoice(payload: dict, db: Session = Depends(get_db)):
    invoice = payload.get("invoice")
    sig_b64 = payload.get("signature_b64")
    cert_pem = payload.get("signing_cert_pem")

    if not invoice or not sig_b64 or not cert_pem:
        raise HTTPException(400, "invoice/signature_b64/signing_cert_pem required")

    # Revocation check (by cert serial)
    from cryptography import x509
    cert = x509.load_pem_x509_certificate(cert_pem.encode())
    serial_hex = format(cert.serial_number, "x")
    revoked = db.query(RevokedCert).filter(RevokedCert.serial_hex == serial_hex).first()
    if revoked:
        return {"valid": False, "reason": f"Certificate revoked: {revoked.reason}", "serial_hex": serial_hex}

    ok, reason = verify_payload_ed25519(cert_pem, invoice, sig_b64)
    return {"valid": ok, "reason": reason, "serial_hex": serial_hex}

# ---------- Admin: revoke cert + audit verify ----------
@app.post("/api/admin/certs/revoke")
def revoke_cert(
    payload: dict,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    require_admin(user)

    cert_pem = payload.get("cert_pem")
    reason = payload.get("reason", "key_compromise")
    if not cert_pem:
        raise HTTPException(400, "cert_pem required")

    from cryptography import x509
    cert = x509.load_pem_x509_certificate(cert_pem.encode())
    serial_hex = format(cert.serial_number, "x")

    existing = db.query(RevokedCert).filter(RevokedCert.serial_hex == serial_hex).first()
    if existing:
        return {"serial_hex": serial_hex, "revoked": True, "already": True}

    row = RevokedCert(serial_hex=serial_hex, reason=reason)
    db.add(row); db.commit()
    append_audit(db, user.id, "revoke_cert", "cert", serial_hex, {"reason": reason})
    return {"serial_hex": serial_hex, "revoked": True}

@app.get("/api/admin/audit/verify-chain")
def admin_verify_audit(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    require_admin(user)
    ok, msg = verify_chain(db)
    return {"valid": ok, "message": msg}

@app.get("/api/admin/certs/current")
def get_current_signing_cert(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    require_admin(user)

    cert = load_signing_cert()
    cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode()

    return {"cert_pem": cert_pem}


@app.post("/api/admin/seed-products")
def seed_products(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
):
    user = get_current_user(db, authorization)
    require_admin(user)

    # Only seed if empty (prevents duplicates)
    if db.query(Product).count() > 0:
        return {"seeded": False, "message": "Products already exist"}

    demo = [
        {"name": "USB-C Fast Charger 30W", "price": "19.99", "stock": 25, "description": "PD 3.0 compatible charger."},
        {"name": "Wireless Mouse", "price": "12.50", "stock": 40, "description": "2.4GHz wireless ergonomic mouse."},
        {"name": "SSD 1TB (NVMe)", "price": "79.00", "stock": 15, "description": "High-speed NVMe storage."},
        {"name": "Laptop Cooling Pad", "price": "15.00", "stock": 30, "description": "Dual-fan cooling pad."},
    ]
    for d in demo:
        db.add(Product(**d))
    db.commit()

    append_audit(db, user.id, "seed_products", "system", "0", {"count": len(demo)})
    return {"seeded": True, "count": len(demo)}