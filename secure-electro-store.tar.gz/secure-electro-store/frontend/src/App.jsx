import React, { useEffect, useMemo, useState } from "react";
import { api, setToken, getToken } from "./api";

function Login({ onLoggedIn }) {
    const [mode, setMode] = useState("login"); // "login" or "register"
    const [email, setEmail] = useState("admin@local");
    const [password, setPassword] = useState("Admin123!");
    const [err, setErr] = useState("");
    async function submit(e) {
        e.preventDefault();
        setErr("");
        try {
            if (mode === "register") {
                await api("/api/auth/register", {
                    method: "POST",
                    body: { email, password }
                });
            }
            const r = await api("/api/auth/login", {
                method: "POST",
                body: { email, password }
            });
            setToken(r.access_token);
            onLoggedIn(r.role);
        } catch (ex) {
            setErr(ex.message);
        }
    }

    return (
        <div style={{ maxWidth: 420, margin: "40px auto", fontFamily: "system-ui" }}>
            <h2>SecureElectroStore</h2>
            <p>Login (default admin for demo)</p>
            <form onSubmit={submit}>
                <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
                    <button
                        type="button"
                        onClick={() => setMode("login")}
                        style={{ background: mode === "login" ? "#2563eb" : "#6b7280" }}
                    >
                        Login
                    </button>
                    <button
                        type="button"
                        onClick={() => setMode("register")}
                        style={{ background: mode === "register" ? "#2563eb" : "#6b7280" }}
                    >
                        Register
                    </button>
                </div>
                <div>
                    <label>Email</label><br />
                    <input value={email} onChange={e => setEmail(e.target.value)} style={{ width: "100%" }} />
                </div>
                <div style={{ marginTop: 8 }}>
                    <label>Password</label><br />
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} style={{ width: "100%" }} />
                </div>
                {err && <div style={{ color: "crimson", marginTop: 8 }}>{err}</div>}
                <button style={{ marginTop: 12, width: "100%" }}>Login</button>
            </form>
            <hr style={{ margin: "20px 0" }} />
            <p style={{ fontSize: 12 }}>
                HTTPS is served by Caddy. If your browser warns about the local cert, accept it for demo.
            </p>
        </div>
    );
}

function Products({ cart, setCart, role }) {
    const [products, setProducts] = useState([]);
    const [err, setErr] = useState("");

    // admin add product minimal
    const [pname, setPname] = useState("USB-C Charger");
    const [pprice, setPprice] = useState("19.99");
    const [pstock, setPstock] = useState(10);

    async function load() {
        setErr("");
        try {
            const r = await api("/api/products");
            setProducts(r);
        } catch (ex) {
            setErr(ex.message);
        }
    }
    useEffect(() => { load(); }, []);

    function addToCart(p) {
        const next = [...cart];
        const idx = next.findIndex(x => x.product_id === p.id);
        if (idx >= 0) next[idx].qty += 1;
        else next.push({ product_id: p.id, name: p.name, unit_price: p.price, qty: 1 });
        setCart(next);
    }

    async function createProduct() {
        setErr("");
        try {
            await api("/api/admin/products", {
                method: "POST",
                body: { name: pname, price: pprice, stock: Number(pstock), description: "" }
            });
            await load();
        } catch (ex) {
            setErr(ex.message);
        }
    }

    return (
        <div>
            <h3>Products</h3>
            {err && <div style={{ color: "crimson" }}>{err}</div>}
            <div style={{ display: "grid", gap: 10 }}>
                {products.map(p => (
                    <div key={p.id} style={{ border: "1px solid #ddd", padding: 10, borderRadius: 8 }}>
                        <b>{p.name}</b>
                        <div style={{ fontSize: 13 }}>{p.description}</div>
                        <div>Price: {p.price} | Stock: {p.stock}</div>
                        <button onClick={() => addToCart(p)} style={{ marginTop: 8 }}>Add to cart</button>
                    </div>
                ))}
            </div>

            {role === "admin" && (
                <div style={{ marginTop: 20, padding: 10, border: "1px dashed #aaa", borderRadius: 8 }}>
                    <h4>Admin: Add Product (starter)</h4>
                    <div style={{ display: "grid", gap: 6, maxWidth: 420 }}>
                        <input value={pname} onChange={e => setPname(e.target.value)} placeholder="name" />
                        <input value={pprice} onChange={e => setPprice(e.target.value)} placeholder="price" />
                        <input value={pstock} onChange={e => setPstock(e.target.value)} placeholder="stock" />
                        <button onClick={createProduct}>Create</button>
                    </div>
                </div>
            )}
        </div>
    );
}

function Cart({ cart, setCart, onCheckout }) {
    const total = cart.reduce((sum, i) => sum + Number(i.unit_price) * i.qty, 0);

    function setQty(pid, qty) {
        const next = cart.map(x => x.product_id === pid ? { ...x, qty } : x)
            .filter(x => x.qty > 0);
        setCart(next);
    }

    return (
        <div style={{ marginTop: 20 }}>
            <h3>Cart</h3>
            {cart.length === 0 ? <p>Empty</p> : (
                <>
                    {cart.map(i => (
                        <div key={i.product_id} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                            <div style={{ width: 220 }}>{i.name}</div>
                            <div style={{ width: 100 }}>{i.unit_price}</div>
                            <input
                                type="number"
                                min="0"
                                value={i.qty}
                                onChange={e => setQty(i.product_id, Number(e.target.value))}
                                style={{ width: 80 }}
                            />
                        </div>
                    ))}
                    <p><b>Total:</b> {total.toFixed(2)}</p>
                    <button onClick={onCheckout}>Checkout (mock)</button>
                </>
            )}
        </div>
    );
}

function Orders({ onSelectOrder }) {
    const [orders, setOrders] = useState([]);
    const [err, setErr] = useState("");

    async function load() {
        setErr("");
        try {
            const r = await api("/api/orders/my");
            setOrders(r);
        } catch (ex) {
            setErr(ex.message);
        }
    }
    useEffect(() => { load(); }, []);

    return (
        <div style={{ marginTop: 20 }}>
            <h3>My Orders</h3>
            {err && <div style={{ color: "crimson" }}>{err}</div>}
            {orders.map(o => (
                <div key={o.id} style={{ border: "1px solid #ddd", padding: 10, borderRadius: 8, marginBottom: 8 }}>
                    <div><b>Order #{o.id}</b> — Total {o.total} — {o.status}</div>
                    <button style={{ marginTop: 8 }} onClick={() => onSelectOrder(o.id)}>View invoice + verify</button>
                </div>
            ))}
        </div>
    );
}

function VerifyInvoice({ orderId, onLoadedInvoiceBundle }) {
    const [inv, setInv] = useState(null);
    const [verify, setVerify] = useState(null);
    const [err, setErr] = useState("");

    async function load() {
        setErr("");
        setVerify(null);
        try {
            const r = await api(`/api/orders/${orderId}/invoice`);
            setInv(r);
            onLoadedInvoiceBundle?.(r);
        } catch (ex) {
            setErr(ex.message);
        }
    }
    useEffect(() => { if (orderId) load(); }, [orderId]);

    async function doVerify(tamper = false) {
        setErr("");
        try {
            const payload = {
                invoice: tamper ? { ...inv.invoice, total: "0.01" } : inv.invoice,
                signature_b64: inv.signature_b64,
                signing_cert_pem: inv.signing_cert_pem
            };
            const r = await api("/api/crypto/verify-invoice", { method: "POST", body: payload });
            setVerify(r);
        } catch (ex) {
            setErr(ex.message);
        }
    }

    if (!orderId) return null;

    return (
        <div style={{ marginTop: 20 }}>
            <h3>Invoice Verification</h3>
            {err && <div style={{ color: "crimson" }}>{err}</div>}
            {!inv ? <p>Loading…</p> : (
                <>
                    <pre style={{ background: "#f7f7f7", padding: 10, borderRadius: 8, overflow: "auto" }}>
                        {JSON.stringify(inv.invoice, null, 2)}
                    </pre>
                    <button onClick={() => doVerify(false)}>Verify (normal)</button>
                    <button onClick={() => doVerify(true)} style={{ marginLeft: 8 }}>Verify (tampered)</button>
                    {verify && (
                        <div style={{ marginTop: 10 }}>
                            <b>Result:</b> {verify.valid ? "✅ VALID" : "❌ INVALID"}<br />
                            <div>{verify.reason}</div>
                            <div style={{ fontSize: 12 }}>cert serial: {verify.serial_hex}</div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
}
function AdminPanel({ lastInvoiceBundle }) {
    const [msg, setMsg] = useState("");
    const [audit, setAudit] = useState(null);

    async function seed() {
        setMsg("");
        try {
            const r = await api("/api/admin/seed-products", { method: "POST" });
            setMsg(r.seeded ? `✅ Seeded ${r.count} products` : `ℹ️ ${r.message}`);
        } catch (ex) {
            setMsg("❌ " + ex.message);
        }
    }

    async function verifyAudit() {
        setMsg("");
        try {
            const r = await api("/api/admin/audit/verify-chain");
            setAudit(r);
            setMsg(r.valid ? "✅ Audit chain valid" : "❌ Audit chain broken");
        } catch (ex) {
            setMsg("❌ " + ex.message);
        }
    }

    async function revokeCurrentSigner() {
        setMsg("");
        try {
            // Fetch current signing cert from backend (safe & simple)
            const cur = await api("/api/admin/certs/current");
            const r = await api("/api/admin/certs/revoke", {
                method: "POST",
                body: { cert_pem: cur.cert_pem, reason: "demo_revocation" }
            });
            setMsg(`✅ Revoked current signer cert (serial ${r.serial_hex})`);
        } catch (ex) {
            setMsg("❌ " + ex.message);
        }
    }

    async function revokeInvoiceCert() {
        setMsg("");
        if (!lastInvoiceBundle?.signing_cert_pem) {
            setMsg("ℹ️ Place an order first so we have an invoice cert to revoke.");
            return;
        }
        try {
            const r = await api("/api/admin/certs/revoke", {
                method: "POST",
                body: { cert_pem: lastInvoiceBundle.signing_cert_pem, reason: "demo_invoice_revocation" }
            });
            setMsg(`✅ Revoked invoice cert (serial ${r.serial_hex})`);
        } catch (ex) {
            setMsg("❌ " + ex.message);
        }
    }

    return (
        <div style={{ marginTop: 20, padding: 12, border: "1px solid #bbb", borderRadius: 10 }}>
            <h3>Admin Panel (Crypto Demo Controls)</h3>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button onClick={seed}>Seed Demo Products</button>
                <button onClick={verifyAudit}>Verify Audit Chain</button>
                <button onClick={revokeCurrentSigner}>Revoke Current Signing Cert</button>
                <button onClick={revokeInvoiceCert}>Revoke Last Invoice Cert</button>
            </div>

            {msg && <div style={{ marginTop: 10 }}>{msg}</div>}

            {audit && (
                <div style={{ marginTop: 10, fontSize: 13 }}>
                    <div><b>Audit Result:</b> {audit.valid ? "VALID" : "INVALID"}</div>
                    <div>{audit.message}</div>
                </div>
            )}

            <div style={{ marginTop: 10, fontSize: 12, opacity: 0.85 }}>
                Marking demo: revoke cert → invoice verify should fail as “revoked”. Audit verify shows tamper-evident logging.
            </div>
        </div>
    );
}
export default function App() {
    const [role, setRole] = useState("");
    const [cart, setCart] = useState([]);
    const [orderId, setOrderId] = useState(null);
    const [err, setErr] = useState("");
    const [lastInvoiceBundle, setLastInvoiceBundle] = useState(null);

    useEffect(() => {
        const t = getToken();
        if (t) setRole("customer"); // token exists; backend will enforce role anyway
    }, []);

    async function checkout() {
        setErr("");
        try {
            const items = cart.map(i => ({ product_id: i.product_id, qty: i.qty }));
            const r = await api("/api/orders/checkout", { method: "POST", body: { items, address: "demo", payment_ref: "mock" } });
            setCart([]);
            setOrderId(r.order_id);
            alert(`Order placed: #${r.order_id}`);
        } catch (ex) {
            setErr(ex.message);
        }
    }

    if (!getToken()) {
        return <Login onLoggedIn={(r) => setRole(r)} />;
    }

    return (
        <div style={{ maxWidth: 900, margin: "20px auto", fontFamily: "system-ui" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h2>SecureElectroStore</h2>
                <button onClick={() => { localStorage.removeItem("token"); location.reload(); }}>Logout</button>
            </div>

            {err && <div style={{ color: "crimson" }}>{err}</div>}

            <Products cart={cart} setCart={setCart} role={role} />
            <Cart cart={cart} setCart={setCart} onCheckout={checkout} />
            <Orders onSelectOrder={(id) => setOrderId(id)} />
            <VerifyInvoice orderId={orderId} onLoadedInvoiceBundle={setLastInvoiceBundle} />
        </div>
    );
}