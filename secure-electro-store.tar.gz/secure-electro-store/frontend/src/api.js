export function getToken() {
    return localStorage.getItem("token") || "";
  }
  
  export function setToken(t) {
    localStorage.setItem("token", t);
  }
  
  export async function api(path, { method="GET", body=null } = {}) {
    const headers = { "Content-Type": "application/json" };
    const token = getToken();
    if (token) headers["Authorization"] = "Bearer " + token;
  
    const res = await fetch(path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });
  
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data?.detail || data?.message || "Request failed";
      throw new Error(msg);
    }
    return data;
  }