# Secure Electronics Store (Crypto-Focused)

## One-command deployment (Docker)
1) Install Docker Desktop
2) Copy env:
   - cp .env.example .env
3) Run:
   - docker compose up -d --build
4) Open:
   - https://localhost

> Note: Local HTTPS uses Caddy "internal" certificates. Browser may show a warning unless the local CA is trusted.
> This is standard for offline/local demos. For a public domain, Caddy can use Let's Encrypt automatically.

## Demo script (crypto proof)
1) Place an order -> signed invoice generated
2) Verify invoice signature -> VALID
3) Tamper invoice JSON -> verification FAILS
4) Revoke signing certificate -> verification FAILS (revoked)
5) Audit log chain verify -> if any entry altered, chain FAILS

## Services
- Frontend: React (Vite) served via Caddy
- Backend: FastAPI
- DB: PostgreSQL
- HTTPS: Caddy reverse proxy

## Stop / Reset
- Stop: docker compose down
- Full reset: docker compose down -v